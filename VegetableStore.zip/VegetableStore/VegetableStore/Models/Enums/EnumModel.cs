﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VegetableStore.Models.Enums
{
    public class EnumModel
    {
        public int Value { get; set; }

        public string Name { get; set; }
    }
}
