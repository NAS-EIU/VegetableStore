﻿var resources = {
    "ConfirmOK": "OK",
    "ConfirmCancel": "Cancel",
    "AddCartOK": "Add to cart success",
    "RemoveCartOK":"Product has been deleted from cart"
}