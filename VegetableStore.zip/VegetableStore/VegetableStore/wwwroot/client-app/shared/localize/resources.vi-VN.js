﻿var resources = {
    "ConfirmOK": "Đồng ý",
    "ConfirmCancel": "Hủy bỏ",
    "AddCartOK": "Thêm vào giỏ hàng thành công",
    "RemoveCartOK":"Đã xóa sản phẩm khỏi giỏ hàng"
}